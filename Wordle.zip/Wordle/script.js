document.addEventListener('DOMContentLoaded', () => {
    // Game configuration
    const WORD_LENGTH = 5;
    const ATTEMPTS = 6;
    const FLIP_ANIMATION_DURATION = 500; // ms
    
    // Game state
    let currentRow = 0;
    let currentTile = 0;
    let isGameOver = false;
    let currentWord = '';
    
    // Word list - common 5-letter words
    const words = [
        'APPLE', 'BEACH', 'BRAIN', 'BREAD', 'BRUSH', 'CHAIR', 'CHEST', 'CHORD', 'CLICK', 'CLOCK',
        'CLOUD', 'DANCE', 'DIARY', 'DRINK', 'EARTH', 'FLUTE', 'FRUIT', 'GHOST', 'GRAPE', 'GRASS',
        'GREEN', 'HAPPY', 'HEART', 'HOUSE', 'JUICE', 'LIGHT', 'MONEY', 'MUSIC', 'PARTY', 'PIZZA',
        'PLANT', 'RADIO', 'RIVER', 'SALAD', 'SHEEP', 'SHOES', 'SMILE', 'SNACK', 'SNAKE', 'SPICE',
        'SPOON', 'STORM', 'SUGAR', 'SWEAT', 'SWEET', 'TABLE', 'TEETH', 'TIGER', 'TOAST', 'TRAIN',
        'WATER', 'WHALE', 'WHEEL', 'WOMAN', 'WORLD', 'WRITE', 'YOUTH'
    ];
    
    // Initialize the game
    function initGame() {
        // Select a random word
        currentWord = getRandomWord();
        console.log('Secret word:', currentWord); // For debugging
        
        // Create the game board
        createBoard();
        
        // Add event listeners
        addKeyboardListeners();
    }
    
    // Get a random word from the word list
    function getRandomWord() {
        return words[Math.floor(Math.random() * words.length)];
    }
    
    // Create the game board
    function createBoard() {
        const board = document.getElementById('board');
        
        for (let i = 0; i < ATTEMPTS; i++) {
            const row = document.createElement('div');
            row.classList.add('row');
            
            for (let j = 0; j < WORD_LENGTH; j++) {
                const tile = document.createElement('div');
                tile.classList.add('tile');
                tile.setAttribute('data-row', i);
                tile.setAttribute('data-col', j);
                row.appendChild(tile);
            }
            
            board.appendChild(row);
        }
    }
    
    // Add event listeners for keyboard and on-screen keyboard
    function addKeyboardListeners() {
        // Physical keyboard
        document.addEventListener('keydown', handleKeyPress);
        
        // On-screen keyboard
        const keys = document.querySelectorAll('.keyboard-container button');
        keys.forEach(key => {
            key.addEventListener('click', () => {
                const keyValue = key.getAttribute('data-key');
                handleKeyInput(keyValue);
            });
        });
    }
    
    // Handle key press events
    function handleKeyPress(e) {
        if (isGameOver) return;
        
        const key = e.key.toLowerCase();
        
        if (key === 'enter') {
            handleKeyInput('enter');
        } else if (key === 'backspace') {
            handleKeyInput('backspace');
        } else if (/^[a-z]$/.test(key)) {
            handleKeyInput(key);
        }
    }
    
    // Process key input
    function handleKeyInput(key) {
        if (isGameOver) return;
        
        if (key === 'enter') {
            submitGuess();
        } else if (key === 'backspace') {
            deleteLetter();
        } else if (/^[a-z]$/.test(key) && currentTile < WORD_LENGTH) {
            addLetter(key);
        }
    }
    
    // Add a letter to the current tile
    function addLetter(letter) {
        if (currentTile < WORD_LENGTH) {
            const tile = document.querySelector(`[data-row="${currentRow}"][data-col="${currentTile}"]`);
            tile.textContent = letter.toUpperCase();
            tile.setAttribute('data-letter', letter.toUpperCase());
            currentTile++;
        }
    }
    
    // Delete the last letter
    function deleteLetter() {
        if (currentTile > 0) {
            currentTile--;
            const tile = document.querySelector(`[data-row="${currentRow}"][data-col="${currentTile}"]`);
            tile.textContent = '';
            tile.removeAttribute('data-letter');
        }
    }
    
    // Submit the current guess
    function submitGuess() {
        if (currentTile !== WORD_LENGTH) {
            showMessage('Not enough letters');
            shakeRow();
            return;
        }
        
        const guess = getCurrentGuess();
        
        if (!isValidWord(guess)) {
            showMessage('Not in word list');
            shakeRow();
            return;
        }
        
        // Check the guess against the current word
        checkGuess(guess);
    }
    
    // Get the current guess from the tiles
    function getCurrentGuess() {
        let guess = '';
        for (let i = 0; i < WORD_LENGTH; i++) {
            const tile = document.querySelector(`[data-row="${currentRow}"][data-col="${i}"]`);
            guess += tile.getAttribute('data-letter');
        }
        return guess;
    }
    
    // Check if the word is in our word list
    function isValidWord(word) {
        // For simplicity, we'll accept any 5-letter word
        // In a real game, you'd check against a dictionary
        return word.length === WORD_LENGTH;
    }
    
    // Check the guess against the current word
    function checkGuess(guess) {
        const row = document.querySelectorAll(`[data-row="${currentRow}"]`);
        let correctCount = 0;
        
        // Create a map to track remaining letters in the target word
        const letterCount = {};
        for (const letter of currentWord) {
            letterCount[letter] = (letterCount[letter] || 0) + 1;
        }
        
        // First pass: mark correct letters
        for (let i = 0; i < WORD_LENGTH; i++) {
            const tile = row[i];
            const letter = tile.getAttribute('data-letter');
            
            if (letter === currentWord[i]) {
                // Correct position
                setTimeout(() => {
                    animateTile(tile, 'correct');
                    updateKeyboard(letter, 'correct');
                }, i * FLIP_ANIMATION_DURATION / 2);
                
                letterCount[letter]--;
                correctCount++;
            }
        }
        
        // Second pass: mark present and absent letters
        for (let i = 0; i < WORD_LENGTH; i++) {
            const tile = row[i];
            const letter = tile.getAttribute('data-letter');
            
            // Skip letters that were already marked as correct
            if (letter !== currentWord[i]) {
                setTimeout(() => {
                    if (currentWord.includes(letter) && letterCount[letter] > 0) {
                        // Letter is present but in wrong position
                        animateTile(tile, 'present');
                        updateKeyboard(letter, 'present');
                        letterCount[letter]--;
                    } else {
                        // Letter is not in the word
                        animateTile(tile, 'absent');
                        updateKeyboard(letter, 'absent');
                    }
                }, i * FLIP_ANIMATION_DURATION / 2);
            }
        }
        
        // Check if the guess is correct
        if (correctCount === WORD_LENGTH) {
            setTimeout(() => {
                showMessage('Magnificent!');
                isGameOver = true;
                danceTiles();
            }, WORD_LENGTH * FLIP_ANIMATION_DURATION / 2);
        } else {
            // Move to the next row
            currentRow++;
            currentTile = 0;
            
            // Check if the game is over
            if (currentRow === ATTEMPTS) {
                setTimeout(() => {
                    showMessage(`Game over! The word was ${currentWord}`);
                    isGameOver = true;
                }, WORD_LENGTH * FLIP_ANIMATION_DURATION / 2);
            }
        }
    }
    
    // Animate a tile flip with the appropriate color
    function animateTile(tile, state) {
        tile.classList.add('flip');
        setTimeout(() => {
            tile.classList.add(state);
        }, FLIP_ANIMATION_DURATION / 2);
    }
    
    // Update the keyboard key colors
    function updateKeyboard(letter, state) {
        const key = document.querySelector(`[data-key="${letter.toLowerCase()}"]`);
        if (!key) return;
        
        // Only update if the new state is more important than the current state
        // Priority: correct > present > absent
        if (state === 'correct') {
            key.className = ''; // Reset classes
            key.classList.add('key-correct');
        } else if (state === 'present' && !key.classList.contains('key-correct')) {
            key.className = ''; // Reset classes
            key.classList.add('key-present');
        } else if (!key.classList.contains('key-correct') && !key.classList.contains('key-present')) {
            key.className = ''; // Reset classes
            key.classList.add('key-absent');
        }
        
        // Restore the wide-button class if needed
        if (letter.toLowerCase() === 'enter' || letter.toLowerCase() === 'backspace') {
            key.classList.add('wide-button');
        }
    }
    
    // Show a message to the user
    function showMessage(message) {
        const messageContainer = document.getElementById('message-container');
        messageContainer.textContent = message;
        
        // Clear the message after 2 seconds
        setTimeout(() => {
            messageContainer.textContent = '';
        }, 2000);
    }
    
    // Shake the current row when an invalid word is entered
    function shakeRow() {
        const row = document.querySelectorAll(`[data-row="${currentRow}"]`);
        row.forEach(tile => {
            tile.classList.add('shake');
            setTimeout(() => {
                tile.classList.remove('shake');
            }, 500);
        });
    }
    
    // Animate the tiles when the player wins
    function danceTiles() {
        const row = document.querySelectorAll(`[data-row="${currentRow}"]`);
        row.forEach((tile, index) => {
            setTimeout(() => {
                tile.classList.add('dance');
                setTimeout(() => {
                    tile.classList.remove('dance');
                }, 500);
            }, index * 100);
        });
    }
    
    // Start the game
    initGame();
});